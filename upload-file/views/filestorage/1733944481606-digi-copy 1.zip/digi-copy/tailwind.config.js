/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js,jsx}"],
  mode: "jit",
  theme: {
    container: {
      center: true,
    },

    screens: {
      sm: "240px",
      lg: "768px",
      lgx: "1230",
      xl: "1398px",
      xxl: "1536px",
    },
    extend: {
      borderColor: {
        "input-error": "#fc8181",
      },
      boxShadow: {
        "3xl": "0 35px 60px -15px rgba(0, 0, 0, 0.3)",
      },
      animation: {
        pulse: 'pulse 1s infinite',
      },
      keyframes: {
        pulse: {
          '0%': { transform: 'scaleY(1)', 'transform-origin': '50% 50%' },
          '50%': { transform: 'scaleY(0.7)', 'transform-origin': '50% 50%' },
          '100%': { transform: 'scaleY(1)', 'transform-origin': '50% 50%' },
        },
      },
      perspective: {
        1000: "1000px",
      },

      colors: {
        blue: "#BAE0FF",
        green: "#b5eec3",
        yellow: "#ffffb9",
        purple: "#f3e7fd",
        red: "#ffcdce",
        primaryBlue: "#3E91EE",
        buttonCTA: "#8000FF",
        colorText: "#232323",
        lightGreen: "#F5FFF8",
        lightBlue: "#E8F5FF",
        lightYellow: "#FFFFE6",
        lightPurple: "#F4E8FF",
        lightRed: "#FFECEC",
      },
      backgroundImage: (theme) => ({
        "gradient-rainbow": "linear-gradient(180deg, #BAE0FF 0%, #FFFFFF 100%)",
      }),
      fontFamily: {
        roboto: ["Roboto", "sans-serif"],
      },
    },
  },
  plugins: [],

  
};



