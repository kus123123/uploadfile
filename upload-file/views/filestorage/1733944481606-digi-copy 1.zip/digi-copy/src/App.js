import { useEffect } from 'react';
import './App.css';
import ChatWithDigiTek from './chat/ChatWithDigiTek.jsx';

function App() {
  // useEffect(()=>{
  //   window.sessionStorage.clear();
  // }, [])
  return (
    <div className="bg-[#202020] App h-full flex justify-center w-screen">
      <ChatWithDigiTek />
    </div>
  );
}

export default App;
