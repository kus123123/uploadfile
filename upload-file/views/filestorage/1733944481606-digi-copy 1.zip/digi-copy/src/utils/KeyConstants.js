export const chatWithDigiTekHistoryList = "chatWithDigiTekHistoryList";
export const chatWithDigiTekHistoryToken = "chatWithDigiTekHistoryToken";
export const chatWithDigiTekHistoryCompleted =
  "chatWithDigiTekHistoryCompleted";



  