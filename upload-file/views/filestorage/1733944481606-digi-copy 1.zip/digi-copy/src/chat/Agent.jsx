import React, { useEffect, useRef, useState } from "react";
import * as sdk from "@d-id/client-sdk";

const Agent = ({ text}) => {
    const agentId = "agt_f1RpVuCS";
    const clientKey = "Z29vZ2xlLW9hdXRoMnwxMTQ0OTc1MjcyNzAyMzA4NTk4MDI6b1lfLV9kVU1zYU8xN0l2cnNRZTFE";
    const videoElement = useRef(null);
    const [agentManager, setAgentManager] = useState(null);
    const [srcObject, setSrcObject] = useState(null);
    const [value, setValue] = useState("Hello i am Lisa");
    const [isreconnect, setReconnect] = useState(false)
    const [isConnected, setIsConnected] = useState(false)
    const agentManagerRef = useRef(null);

    const callbacks = {
        onSrcObjectReady: (value) => {
            console.log("onSrcObjectReady invoked with value:", value);
            if (videoElement.current) {
                videoElement.current.srcObject = value;
                setSrcObject(value);
            }
        },
        // onVideoStateChange: (state) => {
        //     console.log(agentManagerRef.current + " agent manager from video state change");
        //     if (videoElement.current) {
        //         if (state === "START" && videoElement.current.srcObject && videoElement.current.srcObject.getVideoTracks()[0]) {
        //             console.log(state + " : it should be start");

        //             const videoTrack =
        //                 videoElement?.current?.srcObject?.getVideoTracks()[0];
        //             if (videoTrack) {
        //                 videoTrack.enabled = true;
        //             }
        //             videoElement.current.muted = false;
        //             videoElement.current.srcObject = srcObject;
        //         }
        //         else if (agentManagerRef.current) {
        //             videoElement.current.muted = false;
        //             videoElement.current.srcObject = null;
        //             videoElement.current.src = agentManagerRef.current.agent.presenter.idle_video;
        //             videoElement?.current?.load()
        //         }
        //     }
        // },
        onVideoStateChange: (state) => {
            console.log("State received:", state);
            console.log("srcObject at state change:", videoElement.current?.srcObject);
        
            if (!videoElement.current) {
                console.error("Video element is not initialized.");
                return;
            }
        
            if (state === "START") {
                console.log("START state detected.");
        
                if (videoElement.current.srcObject) {
                    const videoTracks = videoElement.current.srcObject.getVideoTracks();
                    console.log("Video tracks:", videoTracks);
        
                    if (videoTracks.length) {
                        const videoTrack = videoTracks[0];
                        videoTrack.enabled = true;
                        videoElement.current.muted = false;
                        videoElement.current.srcObject = srcObject;
                    } else {
                        console.error("No video tracks available.");
                    }
                } else {
                    console.error("srcObject is not set on the video element.");
                }
            } else if (agentManagerRef.current) {
                console.log("Fallback: Using idle video.");
        
                const idleVideo = agentManagerRef.current.agent.presenter.idle_video;
                if (idleVideo) {
                    videoElement.current.muted = false;
                    videoElement.current.srcObject = null;
                    videoElement.current.src = idleVideo;
                    videoElement.current.load();
                } else {
                    console.error("Idle video is not defined.");
                }
            }
        }
        ,        
        onConnectionStateChange: (state) => {
            try {
                console.log("onConnectionStateChange:", state);
                if (state === "disconnected" || state === "connecting") {
                    setReconnect(true)
                } else if (state === "connected") {
                    setTimeout(() => {
                        setIsConnected(true)

                    }, 2000);
                } else {
                    setReconnect(false)

                }

            } catch (err) {
                console.log(err);
            }
        },
        onError: (error, errorData) => {
            console.log("Error:", error, "Error Data:", errorData);
        }
    };

    const streamOptions = { compatibilityMode: "auto", streamWarmup: true };

    useEffect(() => {
        let manager
        (async () => {
            try {
                manager = await sdk.createAgentManager(agentId, {
                    auth: { type: "key", clientKey },
                    callbacks,
                    streamOptions
                });
                setAgentManager(manager);
                agentManagerRef.current = manager;
                try {
                    await manager.connect();
                }
                catch (connectError) {
                    if (connectError?.kind === "TooManyRequestsError" || connectError.status === 429 || connectError.status === 400) {
                        setReconnect(true)
                        console.warn(
                            "Too many requests during connection, try again later:",
                            connectError.description
                        );
                    } else {
                        setReconnect(true)
                        console.warn("Error during manager connection:", connectError);
                    }
                }

                if (manager && isreconnect) {
                    manager.reconnect();
                }

            }
            catch (error) {
                if (error?.kind === "TooManyRequestsError") {
                    setReconnect(true)
                    console.warn(
                        "Too many requests, try again later:",
                    );
                }

            }
        })();

        return () => {
            if (manager) {
                console.log("Disconnecting agent manager...");
                manager.disconnect();
            }
        };
    }, []);


    useEffect(() => {
        if (text) {
            const recommendedProducts = text?.products_recommended            || [];
            setValue(
                `${text.first_sentence || ""} ${recommendedProducts
                    .map((item) => item?.name)
                    .join(". ")}`
            );
        }
    }, [text]);

    //   Trigger `speak` when `value` changes
    useEffect(() => {
        const speak = async () => {
            if (agentManager && value && isConnected) {
                try {
                    console.log(value, "Speak please");
                    await agentManager.speak({ type: "text", input: value });
                } catch (err) {
                    console.error("Error in speak:", err);
                }
            }
        };
        speak();
    }, [value]);


    return (
        <div className="">
            {videoElement &&
                <video
                    width="250px"
                    height="250px"
                    className="rounded-full "
                    loop
                    ref={videoElement}
                    id="videoElement"
                    autoPlay
                    controls={false}
                ></video>
                // :
                // <video
                //     width="250px"
                //     height="250px"
                //     className="rounded-full "
                // ><source src={agentManager?.agent?.presenter?.idle_video} /></video>
            }
        </div>
    );
};

export default Agent;