import React, { useState } from 'react'
import logo from "../assets/Digitek.png"
import arrow from "../assets/arrow.svg"

const Email = () => {
    const [email, setEmail] = useState("")
    const saveEmail = () => {
        email &&
        sessionStorage.setItem("email", email)
        window.location.reload()
    }
  return (
    <div className='flex flex-col items-center justify-between p-4 w-screen h-[60%]'>
        <img src={logo} className="w-52 h-16 p-2" alt="Digitek Logo" />
        <form className='w-80 flex flex-col items-center gap-3 justify-center'  onSubmit={(e) => { e.preventDefault(); saveEmail();}}>
            
            <input type='email'
            placeholder='Enter your email'
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        className='w-full bg-white p-3 rounded-lg' />
       
        <button className='px-4 py-2 rounded-lg flex gap-1 bg-white' type='submit'><p>Next </p><img className='w-6' src={arrow} /> </button>
        <p className='text-white mt-8 w-full lg:w-max  italic text-sm '>This email will be used to personalize our communication with you.</p>

        </form>
    </div>
  )
}

export default Email
