import React, { useEffect, useState } from "react";
import chat from "../assets/ai-chat.png";
import mic from "../assets/microphone.svg";
import pause from "../assets/pause.svg";

const AskQuestion = ({ getter, loading, error, question, setQuestion }) => {
  const [isRender, setIsRedered] = useState(false);
  const [placeholder, setPlaceholder] = useState("")
  useEffect(() => {
    setQuestion("");
  }, [loading]);

  let recognization = new window.webkitSpeechRecognition();

  const vtfn = () => {
    recognization.onstart = () => {
    //   setQuestion("Listening...");
      setPlaceholder("Listening...")
      if (speechSynthesis.speaking) {
        speechSynthesis.cancel(); // Abort speech synthesis
      }
    };
    recognization.onresult = (e) => {
      var transcript = e.results[0][0].transcript;
      setQuestion(transcript);
      getter(e.results[0][0].transcript);
      setPlaceholder("Chat with Alex")
    };
    recognization.start();
  };

  const stopListening = () => {    
    recognization.stop();
    setPlaceholder("Chat with Alex")
  };

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        getter(question);
      }}
      className={` order-last absolute flex border-2 rounded-full bottom-0 bg-white w-full lg:w-2/3 mb-2 gap-2 ${
        !isRender && "-translate-y-[300%]"
      }`}
    >
      <input
        className="appearance-none focus:outline-none w-full  rounded-full  py-2 px-4"
        placeholder= {placeholder ? placeholder : "Chat with Alex"}
        value={question}
        onChange={(e) => setQuestion(e.target.value)}
      />
      {question ? (
        <button
          onClick={() => {
            getter(question);
            setIsRedered(true);
          }}
        >
          <img src={chat} className="w-6 mr-3" />
        </button>
      ) : placeholder === "Listening..." ? (
        <button
          onClick={() => {
            stopListening();
            setIsRedered(true);
          }}
        >
          <img src={pause} className="w-6 mr-3" />
        </button>
      ) : (
        <button
          onClick={() => {
            vtfn();
            setIsRedered(true);
          }}
        >
          <img src={mic} className="w-6 mr-3" />
        </button>
      )}
    </form>
  );
};

export default AskQuestion;
