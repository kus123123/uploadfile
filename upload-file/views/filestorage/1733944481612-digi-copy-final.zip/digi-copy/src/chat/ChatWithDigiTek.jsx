import Agent from "./Agent";
import ChatBox from "./chatBox";
import { useChat } from "./ChatContext";
import Email from "./Email";


const ChatWithDigiTek = () => {

  return (
    <div className={` h-screen w-full flex flex-col items-center justify-center lg:px-3 px-0 lg:w-full`}>
      {sessionStorage.getItem("email") ?
        <div className="lg:w-1/2 w-full h-full">
          <ChatBox />
        </div>
        :
        <div className="h-screen">
        <Email />

        </div>
      }
    </div>
  );
};

export default ChatWithDigiTek;