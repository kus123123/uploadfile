import React, { useState } from 'react'
import { CHAT_WITH_GROOT_HISTORY_API } from '../constants/api';
import { chatWithDigiTekHistoryToken, chatWithDigiTekHistoryList, chatWithDigiTekHistoryCompleted} from '../utils/KeyConstants';

const useHistoryFetch = () => {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const firstTimeHistoryGetter = async () => {
        try {
            setLoading(true);
            const history = JSON.parse(window.sessionStorage.getItem(chatWithDigiTekHistoryList));
            if (!Array.isArray(history)) {
                const res = await fetch(CHAT_WITH_GROOT_HISTORY_API, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'Application/json'
                    },
                    body: JSON.stringify({
                        email: sessionStorage.getItem('email'),
                    })
                });
                if (res.status >= 200 && res.status <= 299) {
                    const ans = await res.json();
                    const historyList = JSON.parse(sessionStorage.getItem(chatWithDigiTekHistoryList));
                    const list = Array.isArray(historyList) ? [...ans.list, ...historyList] : [...ans.list];
                    window.sessionStorage.setItem(chatWithDigiTekHistoryList, JSON.stringify(list));

                    if (ans?.nextToken) {
                        window.sessionStorage.setItem(chatWithDigiTekHistoryToken, JSON.stringify(ans.nextToken));
                    }

                }
                else {
                    const er = await res.json();
                    throw new Error(er?.error);
                }
            }

        }
        catch (err) {

        }
        finally {
            setLoading(false);
        }

    }

    const historyGetter = async () => {
        try {
            const nextToken = sessionStorage.getItem(chatWithDigiTekHistoryToken);
            if (nextToken) {
                setLoading(true);
                const res = await fetch(CHAT_WITH_GROOT_HISTORY_API, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'Application/json'
                    },
                    body: JSON.stringify({
                        email: sessionStorage.getItem('email'),
                        nextToken: sessionStorage.getItem(chatWithDigiTekHistoryToken),
                    })
                });

                if (res.status >= 200 && res.status <= 299) {
                    const ans = await res.json();
                    const historyList = JSON.parse(sessionStorage.getItem(chatWithDigiTekHistoryList));
                    const list = Array.isArray(historyList) ? [...ans, ...historyList] : [...ans];
                    window.sessionStorage.setItem(chatWithDigiTekHistoryList, JSON.stringify(list));

                    if (ans?.nextToken) {
                        window.sessionStorage.setItem(chatWithDigiTekHistoryToken, JSON.stringify(ans.nextToken));
                    }
                    else {
                        window.sessionStorage.removeItem(chatWithDigiTekHistoryToken);
                    }
                }
                else {
                    const er = await res.json();
                    throw new Error(er?.error);
                }
            }

        }
        catch (error) {
            console.log(error.error);
            if (error.error === 'No more history exists') {
                window.sessionStorage.setItem(chatWithDigiTekHistoryCompleted, JSON.stringify(true));
            }
        }
        finally {
            setLoading(false);
        }
    };
    return [loading, error, firstTimeHistoryGetter, historyGetter];
}

export default useHistoryFetch;