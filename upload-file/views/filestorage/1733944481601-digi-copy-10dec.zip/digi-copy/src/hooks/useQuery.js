import React, { useState } from 'react';
import { CHAT_WITH_GROOT_QUERY_API } from '../constants/api';
import { chatWithDigiTekHistoryList } from '../utils/KeyConstants';
import axios from 'axios';

const useQuery = () => {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [speakAns, setSpeakAns] = useState('');
    const emailid = sessionStorage.getItem("email")

    const fn = async (question) => {
        if (!loading && question) {
            const historyList = JSON.parse(sessionStorage.getItem(chatWithDigiTekHistoryList));

            try {
                const que = [{question, answer : null}]
                const justQue = Array.isArray(historyList) ? [...historyList, ...que] : [...que];
                window.sessionStorage.setItem(chatWithDigiTekHistoryList, JSON.stringify(justQue));
                setLoading(true);
                const res = await axios.post(CHAT_WITH_GROOT_QUERY_API, {email: emailid, question: question});
                if (res.status === 200 || res.status <= 299) {
                    const ans = [{question, answer: res.data}];
                    
                    setSpeakAns(ans[0]?.answer)
                    const list = Array.isArray(historyList) ? [...historyList, ...ans] : [...ans];
                    window.sessionStorage.setItem(chatWithDigiTekHistoryList, JSON.stringify(list));
                }
                else if (res.status === 500 || res.status === 402 || res.status === "CORS error") {
                    const er = await res.json();
                    const ans = [{question, answer: ["no", {first_sentence :
                    "Let's try that again, please let me know what you are looking for!"}]}]
                    setSpeakAns(ans[0]?.answer)
                    const list = Array.isArray(historyList) ? [...historyList, ...ans] : [...ans];
                    window.sessionStorage.setItem(chatWithDigiTekHistoryList, JSON.stringify(list));
                    throw new Error(er?.error);
                }
            }
            catch (error) {
                const ans = [{question, answer: ["no", {first_sentence :
                    "Let's try that again, please let me know what you are looking for!" }]}]
                    setSpeakAns(ans[0]?.answer)
                    const list = Array.isArray(historyList) ? [...historyList, ...ans] : [...ans];
                    window.sessionStorage.setItem(chatWithDigiTekHistoryList, JSON.stringify(list));
            }
            finally {
                setLoading(false);
            }
        }
    }



    return [loading, error, fn, speakAns];
}

export default useQuery;