import React, { useState, useEffect, useRef } from "react";
import useHistoryFetch from "../hooks/useHistoryFetch";
import { chatWithDigiTekHistoryList } from "../utils/KeyConstants";
import AskQuestion from "./AskQuestion";
import useQuery from "../hooks/useQuery";
import Agent from "./Agent";
import logo from '../assets/Digitek.png';
import Loader from "./Loader";
import digihalf from "../assets/Digitek_half.png"
import user from "../assets/user.svg"
import AudioWave from "./AudioWave";

const AnswerComponent = ({ text }) => {
  return (
    <div className="flex flex-col my-4 gap-2 lg:flex-row justify-start">
      <img src={digihalf} className="w-6 h-6 mt-2" />
      <div className="gap-4 p-2 border-[1px] text-start rounded-lg border-[#3c3d3c] bg-[#3c3d3c] lg:max-w-[80%] max-w-[90%] flex flex-col ov">
        <p className="text-white">{text?.first_sentence}</p>
        <div className="flex flex-col lg:flex-row flex-wrap gap-5">
          {text?.products_recommended?.[0]?.name === "" ? "" : text?.products_recommended?.map((item, i) => (
            <div key={i} className="flex flex-col bg-[#6b6b6b] lg:p-2 rounded-lg p-2">
              <div className="flex lg:flex-row flex-col gap-4">
                <img src={item.image_url} alt={item.name} className="w-56 h-60 rounded-lg" />
                <div className="flex flex-col gap-2">
                  <p
                    className="hover:text-primaryBlue underline cursor-pointer text-white"
                    onClick={() => window.open(`${item.link}`)}
                  >
                    {item.name}
                  </p>
                  <div className="bg-[#eb1915] py-1 px-2 rounded-lg w-[fit-content]">
                    <p className="text-white">Rs. {item.price}</p>
                  </div>
                  {/* <p className="text-sm text-white">{item.why_is_it_good_fit}</p> */}
                  {item.key_features && item.key_features.length > 0 && (
                    <>
                      <p className="text-sm font-semibold text-white">Key Features:</p>
                      <ul className="list-disc list-inside">
                        {Array.isArray(item.key_features)
                          ? item.key_features.splice(1,3).map((keyf, is) => (
                            <li className="text-sm text-white" key={is}>{keyf}</li>
                          ))
                          : <li className="text-sm text-white">{item.key_features}</li>
                        }
                      </ul>
                    </>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>)


}
const QuestionComponent = ({ text }) => (
  <div className=" my-4 gap-2 flex-col lg:flex-row flex items-end lg:items-center justify-end">
    <p className="order-1 lg:order-0 text-start mr-1 p-2 border-[1px] rounded-lg text-white border-[#3c3d3c] bg-[#3c3d3c] max-w-[90%] lg:max-w-[80%]">
      {text}
    </p>

    <img src={user} className="order-0 mt-2 w-6 h-6 lg:order-1" />
  </div>
);

const ChatBox = () => {
  const [question, setQuestion] = useState("");
  const [audio, setAudio] = useState(false)
  const [historyLoading, historyError, firstHistoryGetter, historyGetter] = useHistoryFetch();
  const history = JSON.parse(window.sessionStorage.getItem(chatWithDigiTekHistoryList));
  const [questionloading, questionError, questionGetter, answerToSpeak] = useQuery();
  const divRef = useRef();
  const greetingText = "Hi, I am Alex. I am here to help you make the right purchase from Digitek";
  console.log(answerToSpeak, history);
  

  useEffect(() => {
    firstHistoryGetter();
  }, []);

  useEffect(() => {
    const speak = (text) => {
      let utterance = new SpeechSynthesisUtterance(text);
      const voices = speechSynthesis.getVoices()
      
      const targetVoice = voices?.find(
        (voice) =>
          voice.name === "Aaron" &&
          voice.lang === "en-US" &&
          voice.voiceURI === "Aaron"
      );
      utterance.voice = targetVoice;
      utterance.lang = targetVoice?.lang;
      speechSynthesis.speak(utterance);
      setAudio(true)

      utterance.onend = () => {
        setAudio(false);
      };
    }
    if (answerToSpeak && answerToSpeak) {
      const products = answerToSpeak?.products_recommended ? answerToSpeak?.products_recommended?.map((item) => item?.name).join(". ") : ""
      const utter = answerToSpeak?.first_sentence + "  " + products
      speak(utter)
    } else {
      speak(greetingText)
    }
    return () => {
      speechSynthesis.cancel();
    };
  }, [answerToSpeak])

  useEffect(() => {
    const scrollHeight = divRef?.current?.scrollHeight;
    divRef?.current?.scrollTo({
      top: scrollHeight,
      left: 0,
      behavior: "smooth"
    });
  }, [questionloading]);

  return (
    <>
      <div
        className={`flex h-full relative flex-col items-center justify-center bg-black lg:px-5 px-2 pt-4 pb-16 rounded-lg sm:relative`}>
        <div className="flex flex-col items-center justify-between w-full">
          <img src={logo} className="w-52 h-16 p-2" alt="Digitek Logo" />
          {/* <Agent text={answerToSpeak} /> */}
          {/* <p className="font-bold text-white text-sm lg:text-lg mb-2">
            Hi, I am Lisa. I am here to help you make the right purchase from Digitek
          </p> */}

          <AudioWave isPlaying={audio}  />
        </div>
        <div ref={divRef} className="overflow-y-auto w-full py-6"
          style={{ height: 'calc(100% - 4rem)' }}
        >
          <div className="flex flex-col my-4 gap-2 lg:flex-row justify-start">
          <img src={digihalf} className="w-6 h-6 mt-2" />
            <div className="w-fit p-2 border-[1px] text-start rounded-lg border-[#3c3d3c] bg-[#3c3d3c]">
              
              <p className="text-white">{greetingText}</p>
            </div></div>
          {history?.map((item, index) => (
            <React.Fragment key={index}>
              {item.question &&
                <QuestionComponent text={item.question} />
              }
              {item?.answer &&
                <AnswerComponent text={item?.answer} />
              }
            </React.Fragment>
          ))}
          {questionloading && (
            <div className=" flex justify-center">
              <Loader />
            </div>
          )}
        </div>
        <AskQuestion
          loading={questionloading}
          error={questionError}
          getter={questionGetter}
          question={question}
          setQuestion={setQuestion}
        />
      </div>
    </>
  );
};

export default ChatBox;
