export const CHAT_WITH_GROOT_HISTORY_API = '';
export const CHAT_WITH_GROOT_QUERY_API = 'https://api.factoq.com/digiapi/query';